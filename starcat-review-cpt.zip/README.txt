=== Starcat Review CPT - CPT Addon for Starcat Review ===
Donate link: http://helpiewp.com/
Tags: review, cpt, starcat
Requires at least: 5.0
Tested up to: 5.2.1
Stable tag: 0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Create Review Posts, add reviews to existing post types and enable user reviews.

== Installation ==
 
1. Upload the plugin to your website.
2. Activate it.
3. Enter the license key you received after the purchase and activate it.
4. Done. You can now go to Helpie KB Wiki -> Helpie Settings and check out the settings or learn more at https://helpiewp.com/docs/

== Change Log ==

= 0.1 =
* Initial release
