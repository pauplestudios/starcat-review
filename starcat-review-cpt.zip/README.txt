=== Starcat Review CPT - CPT Addon for Starcat Review ===
Donate link: http://helpiewp.com/
Tags: review, cpt, starcat
Requires at least: 5.2
Tested up to: 5.4.1
Stable tag: 0.3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Create Review Posts using Reviews Custom Post Type

== Installation ==
 
1. Upload the plugin to your website.
2. Activate it.
3. Enter the license key you received after the purchase and activate it.
4. Done.

== Change Log ==

= 0.3.1 =
* Language Internalization
* German Translation Ready

= 0.3 =
Fix: Activation issues

= 0.2.2 = 
* FIX: FATAL ERROR when Parent plugin is not activated

= 0.2.1 = 
* Introduced Multi-site compatibility

= 0.1 =
* Initial release