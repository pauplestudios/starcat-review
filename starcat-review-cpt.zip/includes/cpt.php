<?php

namespace StarcatReviewCpt\Includes;

use \StarcatReview\Includes\Settings\SCR_Getter;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

if (!class_exists('\StarcatReviewCpt\Includes\Cpt')) {
    class Cpt
    {
        private $post_type_name = SCR_POST_TYPE;

        /* Register post type in init Hook */
        public function register()
        {
            add_action('init', array($this, 'register_post_type_with_taxonomy'));
        }

        /* Register post type on activation hook cause can't call other filter and actions */
        public function register_scr_cpt()
        {
            $this->register_post_type_with_taxonomy();
        }

        public function register_post_type_with_taxonomy()
        {
            $labels = array(
                'name' => __('Reviews', SCR_DOMAIN),
                'singular_name' => __('Review', SCR_DOMAIN),
                'menu_name' => __('Starcat Review', SCR_DOMAIN),
                'name_admin_bar' => __('Review', SCR_DOMAIN),
                'add_new' => __('Add New Review', SCR_DOMAIN),
                'add_new_item' => __('Add New Review', SCR_DOMAIN),
                'new_item' => __('New Review', SCR_DOMAIN),
                'edit_item' => __('Edit Review', SCR_DOMAIN),
                'update_item' => __('Update Review', SCR_DOMAIN),
                'view_item' => __('View Review', SCR_DOMAIN),
                'all_items' => __('All Reviews', SCR_DOMAIN),
                'search_items' => __('Search Reviews', SCR_DOMAIN),
                'not_found' => __('No Reviews found', SCR_DOMAIN),
                'parent_item' => __('Parent Reviews', SCR_DOMAIN),
                'parent_item_colon' => __('Parent Reviews', SCR_DOMAIN) . ':',
                'not_found_in_trash' => __('No Reviews found in Trash.', SCR_DOMAIN),
                'items_list' => __('Review Items list', SCR_DOMAIN),
                'items_list_navigation' => __('Review Items list Navigation', SCR_DOMAIN),
                'filter_items_list' => __('Filter Review Items list', SCR_DOMAIN),
            );

            $cpt_slug = $this->get_cpt_slug();

            $args = array(
                'labels' => $labels,
                'public' => true,
                'menu_position' => 26,
                'menu_icon' => 'dashicons-star-filled',
                'show_in_nav_menus' => true,
                'show_in_rest' => true,
                'map_meta_cap' => true,
                'can_export' => true,
                'has_archive' => true,
                'exclude_from_search' => false,
                'supports' => array('title', 'editor', 'excerpt', 'custom-fields', 'comments', 'revisions', 'page-attributes', 'post-formats', 'thumbnail', 'author'),
                'rewrite' => array('slug' => $cpt_slug, 'with_front' => false),
            );

            register_post_type($this->post_type_name, $args);
            $this->register_category();
            // $this->register_tag();

            flush_rewrite_rules();
        }

        public function register_category()
        {
            $labels = array(
                'name' => __('Review Categories', SCR_DOMAIN),
                'singular_name' => __('Review Category', SCR_DOMAIN),
                'search_items' => __('Search Review Categories', SCR_DOMAIN),
                'all_items' => __('All Review Categories', SCR_DOMAIN),
                'parent_item' => __('Parent Review Category', SCR_DOMAIN),
                'parent_item_colon' => __('Parent Review Category', SCR_DOMAIN) . ':',
                'edit_item' => __('Edit Review Category', SCR_DOMAIN),
                'update_item' => __('Update Review Category', SCR_DOMAIN),
                'add_new_item' => __('Add New Review Category', SCR_DOMAIN),
                'new_item_name' => __('New Review Category Name', SCR_DOMAIN),
                'menu_name' => __('Review Category', SCR_DOMAIN),
            );

            $args = array(
                'hierarchical' => true,
                'labels' => $labels,
                'show_ui' => true,
                'show_in_rest' => true,
                'show_admin_column' => true,
                'query_var' => true,
                'rewrite' => array('slug' => SCR_CATEGORY, 'with_front' => false),
            );

            register_taxonomy(SCR_CATEGORY, array($this->post_type_name), $args);
        }

        public function register_tag()
        {
            $labels = array(
                'name' => _x('Review Tags', 'taxonomy general name', SCR_DOMAIN),
                'singular_name' => _x('Review Tag', 'taxonomy singular name', SCR_DOMAIN),
                'search_items' => __('Search Review Tags', SCR_DOMAIN),
                'all_items' => __('All Review Tags', SCR_DOMAIN),
                'parent_item' => __('Parent Review Tag', SCR_DOMAIN),
                'parent_item_colon' => __('Parent Review Tag', SCR_DOMAIN) . ':',
                'edit_item' => __('Edit Review Tag', SCR_DOMAIN),
                'update_item' => __('Update Review Tag', SCR_DOMAIN),
                'add_new_item' => __('Add New Review Tag', SCR_DOMAIN),
                'new_item_name' => __('New Review Tag Name', SCR_DOMAIN),
                'menu_name' => __('Review Tag', SCR_DOMAIN),
            );

            $args = array(
                'hierarchical' => true,
                'labels' => $labels,
                'show_ui' => true,
                'show_in_rest' => true,
                'show_admin_column' => true,
                'query_var' => true,
                'rewrite' => array('slug' => 'starcat_review_tag', 'with_front' => false),
            );

            register_taxonomy('starcat_review_tag', array($this->post_type_name), $args);
        }

        /* Protected Methods */

        public function get_cpt_slug()
        {

            $cpt_slug = '';
            // if ($settings_getter->get('mp_slug') == 'archive') {
            //     $cpt_slug = $this->mp_settings->get_mp_slug();
            // } else {
            //     $post_id = $this->get_mp_selected_page();
            //     $post = get_post($post_id);
            //     $cpt_slug = $post->post_name;
            // }

            $cpt_slug = SCR_Getter::get('mp_slug');

            return $cpt_slug;
        }
    } // END CLASS
}
