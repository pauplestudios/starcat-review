<?php

namespace StarcatReviewCpt\Includes;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

if (!class_exists('\StarcatReviewCpt\Includes\Hooks')) {
    class Hooks
    {
        public function __construct()
        {
            /*  Reviews Activation Hook */
            // register_activation_hook(SCR_CPT__FILE__, array($this, 'reviews_activate'));

            add_filter('the_content', array($this, 'content_filter'));
        }

        public function reviews_activate()
        {
            /* Register Post Type and its taxonomy only for setup demo content on activation */
            $cpt = new \StarcatReviewCpt\Includes\Cpt();
            $cpt->register_scr_cpt();

            $this->setup_data();
        }

        public function content_filter($content)
        {
            error_log('!!! Hello i am being called !!!');

            $post_type = get_post_type(get_the_ID());
            // Add breadcrumbs for starcat post type only
            if ($post_type == SCR_POST_TYPE) {
                $breadcrumb = new \StarcatReviewCpt\Components\Breadcrumbs\Controller();
                $content = $breadcrumb->get_view() . $content;
            }

            return $content;
        }

        public function setup_data()
        {
            $post_data = [
                'post_type' => SCR_POST_TYPE,
                'taxonomy' => [
                    SCR_CATEGORY => "Getting Started",
                ],
                'title' => "Yours First Reviews Question",
                'content' => "Yours relevent questions answer.",
            ];

            $create_pages = new \StarcatReviewCpt\Includes\Create_Pages();
            $create_pages->setup_data($post_data);
        }
    } // END CLASS

}