<?php

namespace StarcatReviewCpt\Includes;



if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

if (!class_exists('\StarcatReviewCpt\Includes\Hooks')) {
    class Hooks
    {
        public function __construct()
        {
            /*  Reviews Activation Hook */
            register_activation_hook(SCR__FILE__, array($this, 'reviews_activate'));
        }


        public function reviews_activate()
        {
            /* Register Post Type and its taxonomy only for setup demo content on activation */
            $cpt = new \StarcatReviewCpt\Includes\Cpt();
            $cpt->register_scr_cpt();

            $this->setup_data();
        }

        public function setup_data()
        {
            $post_data = [
                'post_type' => SCR_POST_TYPE,
                'taxonomy' => [
                    SCR_CATEGORY => "Getting Started",
                ],
                'title' => "Yours First Reviews Question",
                'content' => "Yours relevent questions answer."
            ];

            $create_pages = new \StarcatReviewCpt\Includes\Create_Pages();
            $create_pages->setup_data($post_data);
        }
    } // END CLASS

}