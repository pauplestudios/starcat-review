<?php

/**
 * Activation Class
 **/
if (!class_exists('SCR_Install_Check')) {
    class SCR_Install_Check
    {
        static function install()
        {
            /**
             * Check if WooCommerce & Cubepoints are active
             **/
            if (
                !is_plugin_active('starcat-review/starcat-review.php')
            ) {

                // Deactivate the plugin
                deactivate_plugins(SCR_CPT__FILE__);

                // Throw an error in the wordpress admin console
                $error_message = __('This plugin requires <a href="http://wordpress.org/extend/plugins/woocommerce/">WooCommerce</a>
&amp; <a href="http://wordpress.org/extend/plugins/cubepoints/">Cubepoints</a> plugins to be active!', 'woocommerce');
                die($error_message);
            }
        }
    }
}

register_activation_hook(SCR_CPT__FILE__, array('SCR_Install_Check', 'install'));