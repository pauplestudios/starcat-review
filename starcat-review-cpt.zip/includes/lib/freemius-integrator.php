<?php
if (!function_exists('scr_cpt_fs')) {
    // Create a helper function for easy SDK access.
    function scr_cpt_fs()
    {
        global $scr_cpt_fs;

        if (!isset($scr_cpt_fs)) {
            // Include Freemius SDK.
            if (file_exists(dirname(dirname(__FILE__)) . '/starcat-review/freemius/start.php')) {
                // Try to load SDK from parent plugin folder.
                require_once dirname(dirname(__FILE__)) . '/starcat-review/freemius/start.php';
            } else if (file_exists(dirname(dirname(__FILE__)) . '/starcat-review-premium/freemius/start.php')) {
                // Try to load SDK from premium parent plugin folder.
                require_once dirname(dirname(__FILE__)) . '/starcat-review-premium/freemius/start.php';
            } else {
                require_once dirname(__FILE__) . '/freemius/start.php';
            }

            $scr_cpt_fs = fs_dynamic_init(array(
                'id'                  => '5122',
                'slug'                => 'starcat-reviews-cpt',
                'type'                => 'plugin',
                'public_key'          => 'pk_8fddc58480a7e2a5406422a545c05',
                'is_premium'          => true,
                'is_premium_only'     => true,
                'has_paid_plans'      => true,
                'parent'              => array(
                    'id'         => '3980',
                    'slug'       => 'starcat-review',
                    'public_key' => 'pk_ad2b6650d9ef2e5df3c203ea9046f',
                    'name'       => 'Starcat Review',
                ),
                'menu'                => array(
                    'support'        => false,
                ),
                // Set the SDK to work in a sandbox mode (for development & testing).
                // IMPORTANT: MAKE SURE TO REMOVE SECRET KEY BEFORE DEPLOYMENT.
                'secret_key'          => 'sk_ogM~u#r:^-B=P~7Km=mnr~$6*K-#y',
            ));
        }

        return $scr_cpt_fs;
    }
}

/* -----                           ---- */
/* ----- Addon Initiation Functions ---- */
/* -----                           ---- */


function scr_cpt_fs_is_parent_active_and_loaded()
{
    // Check if the parent's init SDK method exists.
    return function_exists('hrp_fs');
}

function scr_cpt_fs_is_parent_active()
{
    $active_plugins = get_option('active_plugins', array());

    if (is_multisite()) {
        $network_active_plugins = get_site_option('active_sitewide_plugins', array());
        $active_plugins         = array_merge($active_plugins, array_keys($network_active_plugins));
    }

    foreach ($active_plugins as $basename) {
        if (
            0 === strpos($basename, 'starcat-review/') ||
            0 === strpos($basename, 'starcat-review-premium/')
        ) {
            return true;
        }
    }

    return false;
}

function scr_cpt_fs_init()
{
    if (scr_cpt_fs_is_parent_active_and_loaded()) {
        // Init Freemius.
        scr_cpt_fs();


        // Signal that the add-on's SDK was initiated.
        do_action('scr_cpt_fs_loaded');

        // Parent is active, add your init code here.

    } else {
        // Parent is inactive, add your error handling here.
    }
}

if (scr_cpt_fs_is_parent_active_and_loaded()) {
    // If parent already included, init add-on.
    scr_cpt_fs_init();
} else if (scr_cpt_fs_is_parent_active()) {
    // Init add-on only after the parent is loaded.
    add_action('hrp_fs_loaded', 'scr_cpt_fs_init');
} else {
    // Even though the parent is not activated, execute add-on for activation / uninstall hooks.
    scr_cpt_fs_init();
}