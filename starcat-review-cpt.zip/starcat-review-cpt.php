<?php

/*
Plugin Name: Starcat Review - CPT Addon
Plugin URI: https://starcatwp.com
Description: Creates a Custom Post Type for your Starcat Review Plugin
Author: StarcatWP
Version: 0.3.1
Author URI: http://helpiewp.com
Network: True
Text Domain: starcat-review-cpt
Domain Path: /languages

 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

error_log('cpt loading');
require_once plugin_dir_path(__FILE__) . "/includes/lib/freemius-integrator.php";

define('SCR_CPT_VERSION', '0.3.1');
define('SCR_POST_TYPE', 'starcat_review');
define('SCR_CATEGORY', 'scr_category');
define('SCR_CPT__FILE__', __FILE__);
define('SCR_CPT_PLUGIN_BASE', plugin_basename(SCR_CPT__FILE__));
define('SCR_CPT_PATH', plugin_dir_path(SCR_CPT__FILE__));
define('SCR_CPT_URL', plugins_url('/', SCR_CPT__FILE__));

// require_once 'includes/lib/plugin-dependency-checker.php';
// add_action( 'admin_init', 'starcat_review_cpt_register', 10  );
// add_action( 'plugins_loaded', 'starcat_review_cpt_run', 10  );

register_activation_hook(__FILE__, 'starcat_review_cpt_deactivation');
starcat_review_cpt_run();

// error_log('is_starcat_parent_active: ' . $is_starcat_parent_active);

// function starcat_review_cpt_register(){
//     register_activation_hook(__FILE__, 'starcat_review_cpt_deactivation');
// }

function starcat_review_cpt_run()
{
    remove_action('admin_notices', 'starcat_review_cpt_fail_dependency');
    $is_starcat_parent_active = scr_cpt_fs_is_parent_active_and_loaded(); // from freemius-integrator, different for different addons

    if (!version_compare(PHP_VERSION, '5.4', '>=')) {
        add_action('admin_notices', 'starcat_review_cpt_fail_php_version');
    } elseif (!version_compare(get_bloginfo('version'), '4.5', '>=')) {
        add_action('admin_notices', 'starcat_review_cpt_fail_wp_version');
    } else if (
        !$is_starcat_parent_active
    ) {
        add_action('admin_notices', 'starcat_review_cpt_fail_dependency');
        add_action('scr_fs_loaded', 'starcat_review_cpt_run');
        // starcat_review_cpt_deactivation();
    } else if (!scr_cpt_fs()->can_use_premium_code()) {
        add_action('admin_notices', 'show_starcat_review_cpt_license_message');
    } else {
        require SCR_CPT_PATH . 'includes/plugin.php';
    }
}

function show_starcat_review_cpt_license_message()
{

    $message = sprintf(esc_html__('Activate License for this plugin (Starcat Review - CPT Addon)', 'starcat-review'));
    $html_message = sprintf('<div class="error src-error missing-parent">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}

function starcat_review_cpt_deactivation()
{
    $is_starcat_parent_active = scr_cpt_fs_is_parent_active_and_loaded(); // from freemius-integrator, different for different addons

    if (
        !$is_starcat_parent_active
    ) {
        // error_log('starcat_review_cpt_deactivation');
        // Deactivate the plugin
        deactivate_plugins(SCR_CPT__FILE__);
        $error_message = get_starcat_review_cpt_fail_dependency_message();
        die($error_message);
    } else {
        // Do Nothing.
    }
}

function starcat_review_cpt_fail_dependency()
{
    /* translators: %s: PHP version */
    $message = get_starcat_review_cpt_fail_dependency_message();
    $html_message = sprintf('<div class="error src-error missing-parent">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}

function get_starcat_review_cpt_fail_dependency_message()
{
    return sprintf(esc_html__('This plugin (Starcat Review - CPT Addon) requires Starcat Reviews Pro plugin', 'starcat-review'));
}

/**
 * Show in WP Dashboard notice about the plugin is not activated (PHP version).
 *
 * @since 1.0.0
 *
 * @return void
 */
function starcat_review_cpt_fail_php_version()
{
    /* translators: %s: PHP version */
    $message = sprintf(esc_html__('Starcat Review requires PHP version %s+, plugin is currently NOT ACTIVE.', 'starcat-review'), '5.4');
    $html_message = sprintf('<div class="error">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}

/**
 * Show in WP Dashboard notice about the plugin is not activated (WP version).
 *
 * @since 1.5.0
 *
 * @return void
 */
function starcat_review_cpt_fail_wp_version()
{
    /* translators: %s: WP version */
    $message = sprintf(esc_html__('Starcat Review requires WordPress version %s+. Because you are using an earlier version, the plugin is currently NOT ACTIVE.', 'starcat-review'), '4.5');
    $html_message = sprintf('<div class="error">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}
