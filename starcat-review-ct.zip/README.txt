=== Starcat Review CPT - CPT Addon for Starcat Review ===
Donate link: http://starcatwp.com/
Tags: review, cpt, starcat
Requires at least: 5.2
Tested up to: 5.4.1
Stable tag: 0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Create Comparison Tables for Starcat Reviews

== Installation ==
 
1. Upload the plugin to your website.
2. Activate it.
3. Enter the license key you received after the purchase and activate it.
4. Done.

== Change Log ==

= 0.2 =
* Fix: Activation Issues

= 0.1 =
* Initial release
* Basic Starcat Review Comparison Table

