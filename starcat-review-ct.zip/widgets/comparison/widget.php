<?php

namespace StarcatReviewCt\Widgets\Comparison;

use StarcatReview\Includes\Settings\SCR_Getter;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

if (!class_exists('\StarcatReviewCt\Widgets\Comparison\Widget')) {
    class Widget
    {

        public function load()
        {
            // Shortcode
            // add_shortcode('starcat_review_list', array($this, 'reviews_list'));

            // WordPress Widget
            // add_action('widgets_init', [$this, 'register_widget']);

            // Elementor Widget
            add_action('elementor/widgets/widgets_registered', [$this, 'register_elementor_widget']);
        }



        public function get_view($args)
        {

            $default_args = $this->get_default_args();
            $component_args = array_merge($default_args, $args);
            // error_log("component_args1" . print_r($component_args, true));
            $component_args = $this->get_interpreted_args($args);   
            // error_log("component_args2" . print_r($component_args, true));
            $component_args = $this->boolean_conversion($component_args);
            $comparison_controller = new \StarcatReviewCt\Components\Comparison\Controller();
            // error_log($component_args);
            return $comparison_controller->get_view($component_args);
        }

        protected function get_interpreted_args($args)
        {
            $posts = $this->get_default_posts($args);
            // error_log("posts containers" . print_r($posts, true));
            
            $component_args['posts'] = $posts;
            $component_args['title'] = $args['title'];
            // $component_args['max_num_of_items'] = $args['max_num_of_items'];
            $component_args['show_type'] = $args['show_type'];
            $component_args['scr_ct_element_id'] = 'scr-ct-' . mt_rand(100000, 999999);
            $component_args['feature_columns'] = $this->get_feature_columns($args);
            return $component_args;
        }

        protected function get_default_posts($args)
        {
            $posts = [];
            $posts_ids = $post_types = array();
            $custom_post_args  = array();

            if($args['post_type'] && $args['post_type'] != ""){
                $post_types = explode(",",$args['post_type']);
            }else{
                $post_types[] = "post";
            }

            $custom_post_args['post_types'] = $post_types;

            // error_log('post_types: ' . print_r($post_types, true));

            if($args['posts']  == "random" || $args['posts'] == ""){
                $fetch_posts = $this->get_recent_posts($custom_post_args);
            }else {
                $posts_ids = explode(",",$args['posts']);      
                if (count($posts_ids) > 0) {
                    $post_args = array(
                        'post__in' => $posts_ids,
                        'post_type' => $custom_post_args['post_types'],
                        'post_status' => array('publish')
                        // 'posts_per_page' => $args['max_num_of_items']
                    );
    
                    $fetch_posts = get_posts($post_args);
                }
            } 
            
            if(count($fetch_posts) > 0){
                foreach ($fetch_posts as $post) {
                    $posts[] = $this->get_scr_ct_post_props($args, $post);
                }
            }
            
            return $posts;
        }

        protected function get_scr_ct_post_props($args, $post)
        {
            $post_info = array();
            $src_user_reviews = array();
            $src_overall_ratings = array();

            if (isset($post)) {
                $post_info['ID'] = $post->ID;
                $post_info['title'] = $this->get_excerpt_title_ct($post->post_title);
                $post_featured_image = get_the_post_thumbnail_url($post->ID);
                $post_info['featured_image_url'] = $post_featured_image != "" ? $post_featured_image : SCR_URL . 'includes/assets/img/dummy-review.jpg';
                $post_info['url']   = get_post_permalink($post->ID);
                
                if (function_exists('scr_get_user_reviews')) {
                    $src_user_reviews = scr_get_user_reviews($post->ID); 
                    $src_user_reviews = $this->get_scr_ct_stat_reviews($src_user_reviews);
                } 

                $post_info['user_reviews'] = $src_user_reviews;
                
                if (function_exists('scr_get_overall_rating')) {
                    $src_overall_ratings = scr_get_overall_rating($post->ID);
                }

                $post_info['overall_ratings'] = $src_overall_ratings;
            }
            // error_log("post_info" . print_r($post_info, true));

            return $post_info;
        }

        
        protected function get_scr_ct_stat_reviews($args)
        {
            $stats = array();
            if (count($args) > 0) {
                $scr_global_stats = SCR_Getter::get('global_stats');
                
                $global_stats = array();
                if (count($scr_global_stats) > 0)  {
                    foreach ($scr_global_stats as $stat) {
                        $global_stats[] = strtoupper($stat['stat_name']);
                    }
                }
                // error_log('scr_global_stats : ' . print_r($args, true));
                if (count($args) == 0 && count($global_stats) > 0) {
                    $stats['rating']  = 0;
                    $stat_args = array();
                    foreach ($global_stats as $stat_name) {
                        $stat_name   = strtoupper($stat_name);
                        $stat_args[$stat_name] = array(
                            'stat_name' => strtoupper($stat_name),
                            'rating'    => 0
                        );
                    }

                    $stats['review_stats'] = $stat_args;
                }else{
                   
                    foreach ($args  as $post_review) {
                        $reviews = isset($post_review->reviews) ? $post_review->reviews : [];
                        if (isset($reviews) && count($reviews) > 0) {
                            $stats['ratings'] = $reviews['rating'];
                            $user_stats = $reviews['stats'];
                            $active_user_review_stats = array();
                            if (count($user_stats) > 0) {
                                /***
                                 * get user stats it only found in global stats, else then cant get that user stat
                                 * */ 
                                foreach ($user_stats as $stat_index => $single_stat) {
                                    $stat_index     = strtoupper($stat_index);
                                    if (in_array($stat_index, $global_stats)) {
                                        $active_user_review_stats[$stat_index] = $single_stat;
                                    }
                                }
                            }
                            $stats['review_stats'] = $active_user_review_stats;
                        }
                    }
                }
            }

            return $stats;
        }


        protected function get_feature_columns($args)
        {
            $feature_columns = array();

            $global_stats = SCR_Getter::get('global_stats');
            $feature_columns[] = "RATINGS";
            if (count($global_stats) > 0) {
                foreach ($global_stats as $stat) {
                    $feature_columns[] = strtoupper($stat['stat_name']);
                }
            }
            return $feature_columns;
        }
        protected function get_collection_props($args)
        { }

        protected function execute_methods_with_queries($args)
        {
            // $this->posts = $this->cat_posts_repo->get_category_posts($args);
        }

        /* PROTECTED METHODS */
        protected function boolean_conversion($args)
        {
            foreach ($args as $key => $arg) {

                if ($arg == 'on') {
                    $args[$key] = true;
                } else if ($arg == 'off') {
                    $args[$key] = false;
                }
            }

            return $args;
        }

        public function get_default_args()
        {
            $args = array();

            // Get Default Values from GET - FIELDS
            $fields = $this->get_fields();
            foreach ($fields as $key => $field) {
                $args[$key] = $field['default'];
            }

            return $args;
        }

        public function get_fields()
        {

            $src_ct_posts_options = $this->get_src_ct_posts(true);
            $scr_ct_post_type_options = $this->get_src_ct_post_types(true);

            $fields = array(
                'title' => [
                    'name' => 'title',
                    'label' => __('Title', 'starcat-review-ct'),
                    'default' => 'Starcat Review Product Compare Table',
                    'type' => 'text',
                ],
                'show_type' => [
                    'name' => 'show_type',
                    'label' => __('Show Compare Table Type', 'starcat-review-ct'),
                    'default' => 'static',
                    'options' => array(
                        'static' => __('Static', 'starcat-review-ct'),
                        'dynamic' => __('Dynamic', 'starcat-review-ct')
                    ),
                    'type' => 'select',
                ],
                'post_type' => [
                    'name' => 'scr_ct_post_type',
                    'label' => __('Show Compare Post Type', 'starcat-review-ct'),
                    'default' => 'post',
                    'options' => $scr_ct_post_type_options,
                    'type' => 'select',
                ],
                'posts' => [
                    'name' => 'posts',
                    'label' => __('Choose Values', 'starcat-review-ct'),
                    'default' => 'random',
                    'options' => $src_ct_posts_options,
                    'type' => 'multi-select',
                ],
            );


            return $fields;
        }

        public function get_src_ct_posts()
        {
            $post_options = array();
            $get_post_types = SCR_Getter::get('review_enable_post-types');
            // error_log('get_post_types : ' . print_r($get_post_types, true));
            $args = array(
                'post_type' => $get_post_types,
                'post_status' => array('publish'),
                'nopaging' => true,
                'order' => 'ASC',
                'orderby' => 'menu_order',
            );
            $results = new \WP_Query($args);

            if ($results->have_posts()) {
                $post_options['random'] = 'Random';
                foreach ($results->posts as $post) {
                    $post_options[$post->ID] = substr(wp_strip_all_tags($post->post_title), 0, 35) . '...';
                    // $post_options[$post->ID] = $post->post_title;
                }
            }

            return $post_options;
        }

        protected function get_src_ct_post_types()
        {
            $post_types = array();
            $get_post_types = SCR_Getter::get('review_enable_post-types');
            if (is_array($get_post_types) && count($get_post_types) > 0) {
                foreach ($get_post_types as $post_type) {
                    $post_types[$post_type] = $post_type;
                }
            }
            return $post_types;
        }

        public function get_style_config()
        { }

        public function get_posts($args)
        {
            // get posts in globally
            if (isset($args['post_types'])) {
                $post_types = $args['post_types'];
            } else {
                $post_types = array('post');
            }

            $post_args = array(
                'post_type' => $post_types,
                'post_status' => array('publish'),
                'nopaging' => true,
                'order' => 'ASC',
                'orderby' => 'menu_order',
                'posts_per_page' => 3
            );
            $results = new \WP_Query($post_args);

            $posts = array();
            if ($results->have_posts()) {
                foreach ($results->posts as $post) {
                    $posts[] = $post;
                }
            }
        }

        public function get_recent_posts($args = array()){
            // error_log('get_recent_posts : ' . print_r($args, true));
            $recent_post_args = array(
                'numberposts' => 3,
                'post_status' => array('publish'),
                'post_type'   => $args['post_types']
            );
            // Get Recent Posts
            $posts = wp_get_recent_posts($recent_post_args, 'OBJECT');

            return $posts;
        }

        public function get_excerpt_title_ct($post_title){
            if(strlen($post_title) > 60){
                return substr(wp_strip_all_tags($post_title), 0, 60) . '...';
            }
            return $post_title;
        }
    } // END CLASS
}
