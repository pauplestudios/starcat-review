<?php

/*
Plugin Name: Starcat Review - Comparison Table Addon
Plugin URI: https://starcatwp.com
Description: Creates a Comparison Table for your Starcat Review Plugin
Author: StarcatWP
Version: 0.1
Author URI: http://starcatwp.com
Network: True
Text Domain: starcat-review-ct
Domain Path: /languages

 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// require_once plugin_dir_path(__FILE__) . "/includes/lib/freemius-integrator.php";

define('SCR_CT_VERSION', '0.1');

define('SCR_CT__FILE__', __FILE__);
define('SCR_CT_PLUGIN_BASE', plugin_basename(SCR_CT__FILE__));
define('SCR_CT_PATH', plugin_dir_path(SCR_CT__FILE__));
define('SCR_CT_URL', plugins_url('/', SCR_CT__FILE__));

/**
 * Storing Settings Options in Database tables feilds using CS_Framework
 */

// define('SCR_OPTIONS', 'scr_options');
// define('SCR_CUSTOMIZE_OPTIONS', 'scr_customize_options');


register_activation_hook(__FILE__, 'starcat_review_ct_activation');
starcat_review_ct_run();

function starcat_review_ct_run()
{
    if (!version_compare(PHP_VERSION, '5.4', '>=')) {
        add_action('admin_notices', 'starcat_review_ct_fail_php_version');
    } elseif (!version_compare(get_bloginfo('version'), '4.5', '>=')) {
        add_action('admin_notices', 'starcat_review_ct_fail_wp_version');
    } else if (
        !in_array('starcat-review/starcat-review.php', apply_filters('active_plugins', get_option('active_plugins')))
    ) {
        add_action('admin_notices', 'starcat_review_ct_fail_dependency');
    } else {
        require SCR_CT_PATH . 'includes/plugin.php';
    }
}

function starcat_review_ct_activation()
{
    if (
        !in_array('starcat-review/starcat-review.php', apply_filters('active_plugins', get_option('active_plugins')))
    ) {
        // Deactivate the plugin
        deactivate_plugins(SCR_CT__FILE__);
        $error_message = get_starcat_review_ct_fail_dependency_message();
        die($error_message);
    }
}

/**
 * Show in WP Dashboard notice about the plugin is not activated (PHP version).
 *
 * @since 1.0.0
 *
 * @return void
 */
function starcat_review_ct_fail_php_version()
{
    /* translators: %s: PHP version */
    $message = sprintf(esc_html__('Starcat Review requires PHP version %s+, plugin is currently NOT ACTIVE.', 'starcat-review'), '5.4');
    $html_message = sprintf('<div class="error">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}

/**
 * Show in WP Dashboard notice about the plugin is not activated (WP version).
 *
 * @since 1.5.0
 *
 * @return void
 */
function starcat_review_ct_fail_wp_version()
{
    /* translators: %s: WP version */
    $message = sprintf(esc_html__('Starcat Review requires WordPress version %s+. Because you are using an earlier version, the plugin is currently NOT ACTIVE.', 'starcat-review'), '4.5');
    $html_message = sprintf('<div class="error">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}


function starcat_review_ct_fail_dependency()
{
    /* translators: %s: PHP version */
    $message = get_starcat_review_ct_fail_dependency_message();
    $html_message = sprintf('<div class="error">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}

function get_starcat_review_ct_fail_dependency_message()
{
    return   sprintf(esc_html__('This plugin (Starcat Review - Comparison Table Addon) requires Starcat Reviews Pro plugin', 'starcat-review'));
}