<?php

namespace StarcatReviewCt\Includes;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly


if (!class_exists('\StarcatReviewCt\Includes\Shortcodes')) {
    class Shortcodes
    {
        public function register()
        {
            add_shortcode('starcat_review_ct', array($this, 'compare_table'));
        }

        public function compare_table($atts)
        {
            error_log('SCR CT ShortCode');
            $ct_widget = new \StarcatReviewCt\Widgets\Comparison\Widget();
            $atts = array(
                'title' => 'Starcat Review Product Compare Table',
                'max_num_of_items'   => 5,
                'show_type'     => 'static',
                'post_type'     => array('post'),
                'posts'         => array()
            );
            $dafaults_args = $ct_widget->get_default_args();
            // error_log("dafaults_args" . print_r($dafaults_args, true));
            $widget_args = shortcode_atts($dafaults_args, $atts);
            // error_log("widget_args" . print_r($widget_args, true));
            return $ct_widget->get_view($widget_args);
        }
    }
}
